#!/bin/sh

rm a.out
rm lex.yy.c
rm y.tab.c